setup:
npm install --global gulp
npm install --save-dev gulp
npm install --save-dev gulp-webserver
gem install compass
npm install gulp-compass --save-dev
npm install gulp-jade --save-dev
npm install --save-dev gulp-s3

to run locally:
gulp