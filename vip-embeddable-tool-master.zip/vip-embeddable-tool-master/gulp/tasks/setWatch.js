var gulp = require('gulp');

gulp.task('setWatch', function() {
  global.isWatching = true;
});
